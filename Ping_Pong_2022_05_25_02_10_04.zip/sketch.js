//tamanho da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 25;
let raio = diametro / 2;

//velocidades
let velocidadeXBolinha = 5;
let velocidadeYBolinha = 5;

//variaveis da raquete
let xRaquete = 5;
let yRaquete = 150;
let compRaquete = 10;
let alturaRaquete = 90;

//variaveis da raquete do oponente
let xRaqueteOponente = 585;
let yRaqueteOponente = 150;
let velocidadeYOponente;

//placar
let meusPontos = 0;
let pontosOponente = 0;
let colidiu = false;

//sons do jogo
let raquetada;
let ponto;

let chanceDeErrar = 0;

function preload() {
  ponto = loadSound("ponto.wav");
  raquetada = loadSound("raquetada.wav");
}

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  monstraBolinha();
  movimentosBolinha();
  verificaColisao();
  mostraRaquete(xRaquete, yRaquete);

  movimentaRaquete();
  mostraRaquete(xRaqueteOponente, yRaqueteOponente);
  //verificaColisaoRaquete();
  colisaoMinhaRaqueteGit(xRaquete, yRaquete);

  movimenteRaqueteOponente();
  colisaoMinhaRaqueteGit(xRaqueteOponente, yRaqueteOponente);
  incluiPlacar(meusPontos, pontosOponente);
  contagemDePontos();
  preload();
}
function monstraBolinha() {
  circle(xBolinha, yBolinha, diametro);
}
function movimentosBolinha() {
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}
function verificaColisao() {
  if (xBolinha + raio > width || xBolinha - raio < 0) {
    velocidadeXBolinha *= -1;
  }
  if (yBolinha + raio > height || yBolinha - raio < 0) {
    velocidadeYBolinha *= -1;
  }
}

function mostraRaquete(x, y) {
  rect(x, y, compRaquete, alturaRaquete);
}
function movimentaRaquete() {
  if (keyIsDown(UP_ARROW)) {
    yRaquete -= 10;
  }
  if (keyIsDown(DOWN_ARROW)) {
    yRaquete += 10;
  }
}
function verificaColisaoRaquete() {
  if (
    xBolinha - raio < xRaquete + compRaquete &&
    yBolinha - raio < yRaquete + alturaRaquete &&
    yBolinha + raio > yRaquete
  ) {
    velocidadeXBolinha *= -1;
  }
}
function colisaoMinhaRaqueteGit(x, y) {
  colidiu = collideRectCircle(
    x,
    y,
    compRaquete,
    alturaRaquete,
    xBolinha,
    yBolinha,
    raio
  );
  if (colidiu) {
    velocidadeXBolinha *= -1;
    raquetada.play();
  }
}
function movimenteRaqueteOponente() {
  velocidadeYOponente = yBolinha - yRaqueteOponente - compRaquete / 2 - 30;
  yRaqueteOponente += velocidadeYOponente + chanceDeErrar
  calculaChanceDeErrar()
}
function incluiPlacar(placar1, placar2) {
  stroke(255);
  textAlign(CENTER);
  textSize(20);
  fill(color(70, 130, 180));
  rect(180, 10, 40, 21);
  fill(255);
  text(placar1, 200, 26);
  fill(color(70, 130, 180));
  rect(380, 10, 40, 21);
  fill(255);
  text(placar2, 400, 26);
}
function contagemDePontos() {
  if (xBolinha > 585) {
    meusPontos += 1;
    ponto.play();
  }
  if (xBolinha < 15) {
    pontosOponente += 1;
    ponto.play();
  }
}
function calculaChanceDeErrar() {
  if (pontosOponente >= meusPontos) {
    chanceDeErrar += 1
    if (chanceDeErrar >= 39){
    chanceDeErrar = 40
    }
  } else {
    chanceDeErrar -= 1
    if (chanceDeErrar <= 35){
    chanceDeErrar = 35
    }
  }
}
